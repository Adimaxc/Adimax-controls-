ADIMAX PDF WEBSITE INTEGRATION

1. Copy documents/Adimax-Company-Profile.pdf into your existing website's documents/ folder.
2. Copy company-profile.html into the root of your existing website.
3. Make sure it can access your existing css/style.css and js/script.js.
4. Add "Company Profile" to the navigation in index.html, about.html, services.html, projects.html and contact.html:
   <a href="company-profile.html">Company Profile</a>
5. The page provides both an embedded PDF viewer and Open/Download buttons.

The PDF content incorporated is the supplied 14-page Adimax company profile.
